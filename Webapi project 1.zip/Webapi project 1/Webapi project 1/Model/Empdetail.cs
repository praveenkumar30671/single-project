﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Webapi_project_1.Model
{
    public class Empdetail
    {
        public int id { get; set; }
        public int length { get; set; }
        public string srccs { get; set; }
        public string name { get; set; }
        public int age { get; set; }
        public string location { get; set; }
       
        public Double phoneNumber { get; set; }
        
        public string skill { get; set; }
       

        public string email { get; set; }
    }


}
