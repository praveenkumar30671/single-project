﻿using Couchbase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Webapi_project_1.Model;

namespace Webapi_project_1.Interface
{
    public interface EmpdetailInterface
{
        Task<ICluster> Initialize();
        Task<List<Empdetail>> GetEmployees(ICluster cluster,Paging paging);
        Task<Empdetail> GetEmployeById(ICluster cluster, int id);
        Task<Empdetail> DeleteEmployeById(ICluster cluster, int id);
        Task<Empdetail> PostEmploye(ICluster cluster, Empdetail value );
        Task<Empdetail> PutEmployeById(ICluster cluster, int id,Empdetail value);
        Task<List<Empdetail>> GetEmployeescount(ICluster cluster);

        Task<Logindetail> PostLogin(ICluster cluster, Logindetail form);





    }
}
