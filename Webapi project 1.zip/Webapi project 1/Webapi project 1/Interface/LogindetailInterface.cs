﻿using Couchbase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Webapi_project_1.Model;

namespace Webapi_project_1.Interface
{
    public interface LogindetailInterface
    {
        Task<ICluster> Initialize();
        Task<Logindetail> GetLoginDetails(ICluster cluster,Credentials credentials);
        Task<Logindetail> PostLogin(ICluster cluster, Logindetail form);  


    }
}
