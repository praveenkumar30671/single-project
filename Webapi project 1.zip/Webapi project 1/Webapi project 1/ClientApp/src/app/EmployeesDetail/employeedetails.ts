export class Employeedetails {
    id:number;
    srccs:string;
    name: string;
    age: number;
    location: string;   
    phoneNumber: number;   
    skill: string; 
    email:string;
    

    
  //  managerName: string;
  //  address: string;
  //  salary: number;
}

