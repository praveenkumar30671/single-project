import { ChangeDetectorRef,Component } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Router, NavigationStart, NavigationEnd, Event } from '@angular/router';
import { UserInfo } from './Login/user-info';
import { interval, Subject } from 'rxjs';



export interface Entry {
  created: Date;
  id: string;
}

export interface TimeSpan {
  hours: number;
  minutes: number;
  seconds: number;
}

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  emailPattern = "^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$"; 
  s: UserInfo;
  date = new FormControl(new Date());
  serializedDate = new FormControl((new Date()).toISOString());
  title = 'Loginpage';
  showLoadingIndicator = true;
  userinfo:UserInfo;
  constructor(private route: Router, private changeDetector: ChangeDetectorRef, private dialog: MatDialog, private router: Router) {
  
    this.router.events.subscribe((RouterEvent: Event) => {
      if (RouterEvent instanceof NavigationStart) {
        this.showLoadingIndicator = true;
      }
      if (RouterEvent instanceof NavigationEnd) {
        this.showLoadingIndicator = false;
      }
    });
    this.loggedinn();

    this.jsoncard();
   
  }

  Logout(): void {
    localStorage.clear();
    localStorage.removeItem('idd');
    this.route.navigate(['/one']);
    localStorage.setItem('idd', null);



  }
  // openDialog() {
  //   this.dialog.open(DialogboxComponent);

  // }
  loggedinn(): boolean {
    var status = localStorage.getItem('userStatus');


    if (status == 'Y') {
      return true;

    }

    else {
      return false;
    }
  }
  admin() {
    this.userinfo = JSON.parse(localStorage.getItem('idd'));
   // console.log(this.userinfo);
    if (this.userinfo.logintype == "admin") {
    
      return true;
    } else {
      return false;
    }
  }
  superadmin() {
    this.userinfo = JSON.parse(localStorage.getItem('idd'));
    //console.log(this.userinfo);
    if (this.userinfo.logintype == "superadmin") {
   
      return true;
    } else {
      return false;
    }
  }
  public interval;
  private destroyed$ = new Subject();
  newId: string;
  entries: Entry[] = [];


  ngOnInit(): void {
    this.newId = 'first';
    this.addEntry();

    interval(1000).subscribe(() => {
      if (!this.changeDetector['destroyed']) {
        this.changeDetector.detectChanges();
      }
    });
    this.changeDetector.detectChanges();

  }
  getElaspsedTime(entry: Entry): TimeSpan {
    let totalSeconds = Math.floor((new Date().getTime() - entry.created.getTime()) / 1000);;
    let hours = 0;
    let minutes = 0;
    let seconds = 0;


    if (totalSeconds >= 3600) {
      hours = Math.floor(totalSeconds / 3600);
      totalSeconds -= 3600 * hours;
    }
    if (totalSeconds >= 60) {
      minutes = Math.floor(totalSeconds / 60);
      totalSeconds -= 60 * minutes;
    }
    seconds = totalSeconds;

    return {
      hours: hours,
      minutes: minutes,
      seconds: seconds
    };
  }
  addEntry() {
    this.entries.push({
      created: new Date(),
      id: this.newId
    });
    this.newId = '';
  }
  ngOndestroy() {
    this.destroyed$.next();
    this.destroyed$.complete();
  }

  jsoncard() {
    this.s = JSON.parse(localStorage.getItem('idd'));
   // console.log(this.s);

  }

}
