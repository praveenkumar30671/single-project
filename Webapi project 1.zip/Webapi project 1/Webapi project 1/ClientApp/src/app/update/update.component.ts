import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { Employeedetails } from '../EmployeesDetail/employeedetails';
import { LoginServiceService } from '../service/login-service.service';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {
  employee: Employeedetails;
  emp :Employeedetails=new Employeedetails();
  submit:string;
  
  constructor(private createservice: LoginServiceService, router:Router)
  { 
    this.employee=JSON.parse(localStorage.getItem('editdata'))
    console.log(this.employee)
  }

  ngOnInit(): void
  {
  }

  onSubmit(form: NgForm): void {
  if (form.valid)
  {
   console.log(form.value)
   this.createservice.update(form.value).subscribe(m => {
   console.log(m);
    //  form.resetForm();
   this.submit= "**Updated Successfully**"
   window.confirm("Employee Details Updated Successfully")
   })}

   else{
        window.confirm("Please fill the required field")
       }
  }

}