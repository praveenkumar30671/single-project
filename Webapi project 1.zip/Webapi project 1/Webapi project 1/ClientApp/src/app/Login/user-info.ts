export class UserInfo {
    username: string;
    pwd: string;
    photo:string;
    id:any;
    designation:string;
    logintype:string;
}
