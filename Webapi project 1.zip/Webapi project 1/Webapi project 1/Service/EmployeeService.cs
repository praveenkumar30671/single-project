﻿using Couchbase;
using Couchbase.Core.Exceptions;
using Microsoft.Extensions.Logging;
using Polly;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Webapi_project_1.Interface;
using Webapi_project_1.Model;

namespace Webapi_project_1.Services
{
    public class EmployeeService : EmpdetailInterface
    {
        private readonly ILogger<EmployeeService> logger;

        public EmployeeService(ILogger<EmployeeService> logger)
        {
            this.logger = logger;
        }
        public async Task<Empdetail> DeleteEmployeById(ICluster cluster, int id)
        {
            try
            {
                //  var queryResult = await cluster.QueryAsync<Employees>("SELECT username,name,email,age,location,srccs,phoneNumber,salary,skill,managerName,address,id FROM Employees where id= "  + id.ToString()  , new Couchbase.Query.QueryOptions());
                var bucket = await cluster.BucketAsync("Empdetail");


                var collection = bucket.DefaultCollection();

                await collection.RemoveAsync(id.ToString());
                return null;
            }
            catch (BucketNotFoundException)
            {
                logger.LogError("Bucket not found");
                throw;
            }

        }

        public async Task<Empdetail> GetEmployeById(ICluster cluster, int id)
        {
            Empdetail employee = new Empdetail();
            var queryResult = await cluster.QueryAsync<Empdetail>("SELECT username,name,email,age,location,srccs,phoneNumber,skill,id FROM Empdetail where id=" + id, new Couchbase.Query.QueryOptions());



            await foreach (var row in queryResult)
            {
                employee = row;
            }
            if (employee == null)
            {
                logger.LogWarning($"Id with {id} not available in the bucket");
            }

            return employee;
        }



        public async Task<List<Empdetail>> GetEmployees(ICluster cluster, Paging paging)
        {
            try
            {
                var queryResult = await cluster.QueryAsync<Empdetail>($"SELECT username,name,email,age,location,srccs,phoneNumber,skill,id FROM Empdetail OFFSET {paging.start} LIMIT {paging.end}", new Couchbase.Query.QueryOptions());

                List<Empdetail> empList = new List<Empdetail>();

                await foreach (var row in queryResult)
                {
                    empList.Add(row);
                }

                return empList;


            }
            catch (IndexFailureException)
            {
                logger.LogError("Bucket not found");
                throw;
            }


        }

        public async Task<ICluster> Initialize()
        {
            try
            {
                var policy = Policy.Handle<Exception>()
                   .WaitAndRetryAsync(2, count => TimeSpan.FromSeconds(3));
                await policy.ExecuteAsync(async () =>
                {

                    logger.LogInformation("Retrying to connect couchbase for EmployeeController...");
                    await Retry();
                });
                return await Retry();
            }

            catch (AuthenticationFailureException)
            {
                logger.LogError("Authentication error");
                throw;
            }

        }
        public async Task<ICluster> Retry()
        {
            var cluster = await Cluster.ConnectAsync("couchbase://localhost", "Administrator", "Password");
            var bucket = await cluster.BucketAsync("Empdetail");
            var collection = bucket.DefaultCollection();
            return cluster;
        }

        public async Task<Empdetail> PutEmployeById(ICluster cluster, int id, Empdetail value)
        {
            var bucket = await cluster.BucketAsync("Empdetail");
            var collection = bucket.DefaultCollection();
            var collectiondata = await collection.UpsertAsync(id.ToString(), value);

            if (collectiondata == null)
            {
                logger.LogError("Error in update");
            }
            return null;

        }
        //create
        public async Task<Empdetail> PostEmploye(ICluster cluster, Empdetail value)
        {

            var bucket = await cluster.BucketAsync("Empdetail");
            var collection = bucket.DefaultCollection();
            int idvalue = value.id;
            var collectiondataa = await collection.InsertAsync(idvalue.ToString(), value);
            if (collectiondataa == null)
            {
                logger.LogError("Error in creating");
            }

            return null;
        }

        public async Task<List<Empdetail>> GetEmployeescount(ICluster cluster)
        {
            List<Empdetail> employees = new List<Empdetail>();
            var queryResults = await cluster.QueryAsync<Empdetail>("SELECT username,name,email,age,location,srccs,phoneNumber,skill,id FROM Empdetail ", new Couchbase.Query.QueryOptions());



            await foreach (var row in queryResults)
            {
                employees.Add(row);
            }


            return employees;
        }


        public async Task<Logindetail> PostLogin(ICluster cluster, Logindetail form)
        {
            try
            {
                var bucket = await cluster.BucketAsync("Logindetail");
                var collection = bucket.DefaultCollection();
                var idvalue = form.id;
                await collection.InsertAsync(idvalue.ToString(), form);
                return null;
            }
            catch (IndexFailureException)
            {
                logger.LogError("Bucket not found for LoginController");
                throw;
            }
        }



    }
}
    

