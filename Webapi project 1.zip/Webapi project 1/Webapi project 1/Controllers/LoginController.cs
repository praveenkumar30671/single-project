﻿using Microsoft.AspNet.OData;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using Moq;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Webapi_project_1.Interface;
using Webapi_project_1.Model;
using Webapi_project_1.Services;

namespace Webapi_project_1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    public class LoginController : ControllerBase
    {
        private readonly LogindetailInterface _service;
        private readonly ILogger<LoginController> logger;
        private readonly ApplicationSettings _appSettings;

     

        public LoginController(LogindetailInterface Service, ILogger<LoginController> logger, IOptions<ApplicationSettings> appSettings)
        {
            this._service = Service;
            this.logger = logger;
            _appSettings = appSettings.Value;
        }

       // public LoginController(LogindetailInterface object1, ILogger<LoginController> object2, ApplicationSettings object3)
      //  {
      //  }



        // GET: api/<LoginController>
        [HttpGet]
       [EnableQuery()]
        [AllowAnonymous]
        public async Task<LoginCollection> Get([FromQuery] Credentials credentials)
        {logger.LogInformation("Getting all Login details");
            
            var couchClient = await _service.Initialize();
           var loginDetails = await _service.GetLoginDetails(couchClient,credentials);
            LoginCollection login = new LoginCollection();
            if (loginDetails == null)
            {
                logger.LogError("Error in getting Login details");
                return login;
            }
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new Claim[]
                   {

                       new Claim(ClaimTypes.Name, loginDetails.id.ToString()),
                       new Claim(ClaimTypes.Role, loginDetails.logintype.ToString()),

                   }),
                Expires = DateTime.UtcNow.AddMinutes(5),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(Encoding.ASCII.GetBytes(_appSettings.JWT_Secret)), SecurityAlgorithms.HmacSha256Signature)
            };
            var tokenHandler = new JwtSecurityTokenHandler();
            var securityToken = tokenHandler.CreateToken(tokenDescriptor);
            loginDetails.pwd = null;
            login.loginDetails = loginDetails;



            login.token = tokenHandler.WriteToken(securityToken);
            logger.LogInformation(login.token);
            return login;
        }

        // POST api/<LoginController>
       
        [HttpPost]
        [Authorize (Roles = "superadmin,admin")]
        public async Task Post([FromBody] Logindetail form)
        {
            var couchClient = await _service.Initialize();
           var logindata= await _service.PostLogin(couchClient, form);
            if (logindata != null)
            {
                logger.LogInformation("Successfully posted");
            }

        } 

    }
}
