﻿using Couchbase;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using System;
using System.Threading.Tasks;
using Webapi_project_1.Controllers;
using Webapi_project_1.Interface;
using Webapi_project_1.Model;
using Webapi_project_1.Services;
using Xunit;
using NLog;


namespace WebapiTesting
{
    public class EmployeeTest
    {
        private readonly Mock<EmpdetailInterface> _mockservice;
        private readonly Mock<ILogger<EmployeeController>> _mocklogger;
        private readonly Mock<ILogger<EmployeeService>> _mockservicelogger;

        public EmployeeTest()
        {
            this._mocklogger = new Mock<ILogger<EmployeeController>>();
            this._mockservice = new Mock<EmpdetailInterface>();
            this._mockservicelogger = new Mock<ILogger<EmployeeService>>();
        }


        //GET TEST CASES:
        //  1:

        [Fact]
        public void Employeeget_returnEmployeecollection()
        {
            Credentials credential = new Credentials();
            Paging paging = new Paging();
            Empdetail logins= new Empdetail();
            credential.username = "Maheswaran";
            credential.pwd = "bsh1";
            var data = new Empdetail
            {
                id = 1,
                length = 0,
                name = "Vijay",
                srccs = "https://logodix.com/logo/1086329.png",
                age = 23,
                phoneNumber = 9756622836,
                skill = "Data-Analyst",
                email = "vijay@bshg.com",
                location="pune"
            };
            Empdetail emp = new Empdetail();
            logins.id = 1;
            logins.name = "Vijay";
            logins.length = 0;

            EmployeeController employeeController = new EmployeeController(_mockservice.Object, _mocklogger.Object);
            var post = employeeController.Get(paging);
             Assert.Equal(post, post);
        }


      /// 2:

        [Fact]
        public void Employeeget_returnnotNull()
        {
            Credentials credential = new Credentials();
            Paging paging = new Paging();
            Empdetail logins = new Empdetail();
            credential.username = "Maheswaran";
            credential.pwd = "bsh1";
            var data = new Empdetail
            {
                id = 1,
                length = 0,
                name = "Vijay",
                srccs = "https://logodix.com/logo/1086329.png",
                age = 23,
                phoneNumber = 9756622836,
                skill = "Data-Analyst",
                email = "vijay@bshg.com",
                location = "pune"
            };
            Empdetail emp = new Empdetail();
            logins.id = 1;
            logins.name = "Vijay";
            logins.length = 0;

            EmployeeController employeeController = new EmployeeController(_mockservice.Object, _mocklogger.Object);
            var post = employeeController.Get(paging);

            if (post != null)
                Assert.NotNull(post);
        }


        ///3:
        
        [Fact]
        public void Employeeget_NotBadRequest()
        {
            Credentials credential = new Credentials();
            Paging paging = new Paging();
            Empdetail logins = new Empdetail();
            credential.username = "Maheswaran";
            credential.pwd = "bsh1";
            var data = new Empdetail
            {
                id = 1,
                length = 0,
                name = "Vijay",
                srccs = "https://logodix.com/logo/1086329.png",
                age = 23,
                phoneNumber = 9756622836,
                skill = "Data-Analyst",
                email = "vijay@bshg.com",
                location = "pune"
            };
            Empdetail emp = new Empdetail();
            logins.id = 1;
            logins.name = "Vijay";
            logins.length = 0;

            EmployeeController employeeController = new EmployeeController(_mockservice.Object, _mocklogger.Object);
            var post = employeeController.Get(paging);
            Assert.IsType<Empdetail>(data);
        }


        ///  POST TEST CASES:
        ///  1:

        [Fact]
        public void EmployeePost_returnnotNull()
        {
            Credentials credential = new Credentials();
            Paging paging = new Paging();
            Empdetail logins = new Empdetail();
            credential.username = "Maheswaran";
            credential.pwd = "bsh1";
            var data = new Empdetail
            {
                id = 1,
                length = 0,
                name = "Vijay",
                srccs = "https://logodix.com/logo/1086329.png",
                age = 23,
                phoneNumber = 9756622836,
                skill = "Data-Analyst",
                email = "vijay@bshg.com",
                location = "pune"
            };
            Empdetail emp = new Empdetail();
            logins.id = 1;
            logins.name = "Vijay";
            logins.length = 0;

            EmployeeController employeeController = new EmployeeController(_mockservice.Object, _mocklogger.Object);
            var post = employeeController.Post(data);
            if (post != null)
                Assert.NotNull(data);
        }


        /// 2:

        [Fact]
        public void EmployeePost_NotBadRequest()
        {
            Credentials credential = new Credentials();
            Paging paging = new Paging();
            Empdetail logins = new Empdetail();
            credential.username = "Maheswaran";
            credential.pwd = "bsh1";
            var data = new Empdetail
            {
                id = 1,
                length = 0,
                name = "Vijay",
                srccs = "https://logodix.com/logo/1086329.png",
                age = 23,
                phoneNumber = 9756622836,
                skill = "Data-Analyst",
                email = "vijay@bshg.com",
                location = "pune"
            };
            Empdetail emp = new Empdetail();
            logins.id = 1;
            logins.name = "Vijay";
            logins.length = 0;

            EmployeeController employeeController = new EmployeeController(_mockservice.Object, _mocklogger.Object);
            var post = employeeController.Post(data);
            Assert.IsType<Empdetail>(data);
        }


        ///  UPDATE TEST CASES:
        ///  1:

        [Fact]
        public void EmployeeUpdate_returnnotNull()
        {
            Credentials credential = new Credentials();
            Paging paging = new Paging();
            Empdetail logins = new Empdetail();
            credential.username = "Maheswaran";
            credential.pwd = "bsh1";

            var data = new Empdetail
            {
                id = 1,
                length = 0,
                name = "Vijay",
                srccs = "https://logodix.com/logo/1086329.png",
                age = 23,
                phoneNumber = 9756622836,
                skill = "Data-Analyst",
                email = "vijay@bshg.com",
                location = "pune"
                
            };
            int id = data.id;
            Empdetail emp = new Empdetail();
            logins.id = 1;
            logins.name = "Vijay";
            logins.length = 0;

            EmployeeController employeeController = new EmployeeController(_mockservice.Object, _mocklogger.Object);
            var post = employeeController.Put(id,data);
            if (post != null)
                Assert.NotNull(data);
        }


        /// 2:

          [Fact]
         public void EmployeeUpdate_NotBadRequest()
         {
             Credentials credential = new Credentials();
             Paging paging = new Paging();
             Empdetail logins = new Empdetail();
             credential.username = "Maheswaran";
             credential.pwd = "bsh1";

             var data = new Empdetail
             {
                 id = 1,
                 length = 0,
                 name = "Vijay",
                 srccs = "https://logodix.com/logo/1086329.png",
                 age = 23,
                 phoneNumber = 9756622836,
                 skill = "Data-Analyst",
                 email = "vijay@bshg.com",
                 location = "pune"

             };
             int id = data.id;
             Empdetail emp = new Empdetail();
             logins.id = 1;
             logins.name = "Vijay";
             logins.length = 0;

             EmployeeController employeeController = new EmployeeController(_mockservice.Object, _mocklogger.Object);
             var post =  employeeController.Put(id,data);
             Assert.IsNotType<BadRequestResult>(post);

         }



       /// DELETE TEST CASES:
         /// 1:

        [Fact]
         public void EmployeeDelete_deletesEmployeecollection()
         {
             Credentials credential = new Credentials();
             Paging paging = new Paging();
             Empdetail logins = new Empdetail();
             credential.username = "Maheswaran";
             credential.pwd = "bsh1";
             var data = new Empdetail
             {
                 id = 1,
                 length = 0,
                 name = "Vijay",
                 srccs = "https://logodix.com/logo/1086329.png",
                 age = 23,
                 phoneNumber = 9756622836,
                 skill = "Data-Analyst",
                 email = "vijay@bshg.com",
                 location = "pune"
             };
           // int id = 1;
             Empdetail emp = new Empdetail();
             logins.id = 1;
             logins.name = "Vijay";
             logins.length = 0;

             EmployeeController employeeController = new EmployeeController(_mockservice.Object, _mocklogger.Object);
            var post =  employeeController.Delete(logins.id);
             Assert.Equal(data,data);
         }

    }
}
