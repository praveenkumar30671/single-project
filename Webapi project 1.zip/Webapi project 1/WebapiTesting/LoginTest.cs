﻿using Couchbase;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using System;
using System.Threading.Tasks;
using Webapi_project_1.Controllers;
using Webapi_project_1.Interface;
using Webapi_project_1.Model;
using Webapi_project_1.Services;
using Xunit;
using NLog;


namespace LoginTest
{
    public class LoginTesting
    {
        private readonly Mock<LogindetailInterface> _mockservice;
        private readonly Mock<ILogger<LoginController>> _mocklogger;
        private readonly Mock<ILogger<LoginService>> _mockservicelogger;
        private readonly Mock<IOptions<ApplicationSettings>> _mockappSettings;

        public LoginTesting()
        {
            this._mockservice = new Mock<LogindetailInterface>();
            this._mocklogger = new Mock<ILogger<LoginController>>();
            this._mockservicelogger = new Mock<ILogger<LoginService>>();
            this._mockappSettings = new Mock<IOptions<ApplicationSettings>>();
        }


        ///  GET TEST CASES
        /// 1:

        [Fact]
        public void Loginget_returnLogincollection()
        {
            Credentials credentials = new Credentials();
            Logindetail employees = new Logindetail();
            credentials.username = "Maheswaran";
            credentials.pwd = "bsh1";
            var data = new Logindetail
            {
                id = 1,
                username = "Maheswaran",
                pwd = "bsh1",
                designation = "Full-Stack developer",
                logintype = "superadmin"
            };
            Logindetail login = new Logindetail();
            employees.id = 1;
            employees.username = "Maheswaran";
            employees.pwd = "bsh1";

            LoginController loginController = new LoginController(_mockservice.Object, _mocklogger.Object, _mockappSettings.Object);
            var post = loginController.Get(credentials);
            Assert.Equal(post, post);
        }


        /// 2:

        [Fact]
        public void Loginget_returnnotnull()
        {
            Credentials credentials = new Credentials();
            Logindetail employees = new Logindetail();
            credentials.username = "Maheswaran";
            credentials.pwd = "bsh1";
            var data = new Logindetail
            {
                id = 1,
                username = "Maheswaran",
                pwd = "bsh1",
                designation = "Full-Stack developer",
                logintype = "superadmin"
            };
            Logindetail login = new Logindetail();
            employees.id = 1;
            employees.username = "Maheswaran";
            employees.pwd = "bsh1";

            LoginController loginController = new LoginController(_mockservice.Object, _mocklogger.Object, _mockappSettings.Object);
            var post = loginController.Get(credentials);
            if (post != null)
                Assert.NotNull(post);
        }


        /// 3:

        [Fact]
        public void Loginget_NotBadRequest()
        {
            Credentials credentials = new Credentials();
            Logindetail employees = new Logindetail();
            credentials.username = "Maheswaran";
            credentials.pwd = "bsh1";
            var data = new Logindetail
            {
                id = 1,
                username = "Maheswaran",
                pwd = "bsh1",
                designation = "Full-Stack developer",
                logintype = "superadmin"
            };
            Logindetail login = new Logindetail();
            employees.id = 1;
            employees.username = "Maheswaran";
            employees.pwd = "bsh1";

            LoginController loginController = new LoginController(_mockservice.Object, _mocklogger.Object, _mockappSettings.Object);
            var post = loginController.Get(credentials);
            Assert.IsNotType<BadRequestResult>(post);
        }

        


    }
}